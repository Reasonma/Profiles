## 说明

可以使用本目录下的流媒体分流文件按区域分流。

但需要注意的是，如 YouTube、Netflix、Amazon Prime Video 这类覆盖地区广泛或没有进行区域限制的流媒体服务并不在其中。